#include <stdio.h>

void q1(void);
void rotateArr(int(*Arr)[4]);

void q2(void);
void q3(void);
void q4(void);
void q5(void);
void q6(void);

int main(void)
{
	// init
	int nQuest = 1;

	while (nQuest != 0)
	{
		// enter question number
		printf("enter question number\n");
		scanf("%d", &nQuest);

		switch (nQuest)
		{
		case 1:
			q1();
			break;

		case 2:
			q2();
			break;

		case 3:
			q3();
			break;

		case 4:
			q4();
			break;

		case 5:
			q5();
			break;

		case 6:
			q6();
			break;

		default:
			break;
		}
	}
	return 0;
}

void q1(void)
{	
	// init
	int Arr[4][4];
	int i = 0, j = 0;
	int nNum = 1;

	for (i = 0; i < 4; i++)	// init Arr (1 to 16)
	{
		for (j = 0; j < 4; j++)
		{
			Arr[i][j] = nNum;
			nNum++;
		}
	}

	for (i = 0; i < 4; i++)	// rotate 4 times
	{
		rotateArr(Arr);
		printf("\n");
	}

	printf("\n");	// end of q1
}

void rotateArr(int (*Arr)[4])
{
	// init
	int i = 0, j = 0;
	int tempArr[4][4];

	// let's think this array is on the center of 'coordinate system'. (Zero Point is Arr[1.5][1.5]) 
	for (i = 0; i < 4; i++)	// flip by "y = -x"
	{
		for (j = 0; j < 4; j++)
		{
			tempArr[i][j] = Arr[j][i];
		}
	}

	for (i = 0; i < 4; i++)	// flip by "x = 0"
	{
		for (j = 0; j < 4; j++)
		{
			Arr[i][j] = tempArr[i][3 - j];
			printf("%2d ", Arr[i][j]);	// print Arr
		}
		printf("\n");
	}	
	
	// end rotateArr
}
	

void q2(void)
{
	// init size of array
	int szNum = 0, nNum = 1;
	printf("enter number\n");
	scanf("%d", &szNum);
	int nCnt = szNum;
	int szTemp = szNum;

	// init array
	int Arr2[szNum][szNum];
	int i = 0, j = 0;


	while (nCnt > 0)
	{
		Arr2[i][j] = nNum;
		printf("%d ", Arr2[i][j]);
		nCnt--;
		nNum++;
		j++;
	}

	j--;
	szTemp -= 1;
	nCnt = szTemp;

	printf("\n");

	
	while (nCnt > 0)
	{
		while (nCnt > 0)
		{
			i++;
			Arr2[i][j] = nNum;
			printf("%d ", Arr2[i][j]);
			nCnt--;
			nNum++;
		}

		printf("\n");
		nCnt = szTemp;

		while (nCnt > 0)
		{
			j--;
			Arr2[i][j] = nNum;
			printf("%d ", Arr2[i][j]);
			nCnt--;
			nNum++;
		}

		printf("\n");
		szTemp -= 1;
		nCnt = szTemp;

		while (nCnt > 0)
		{
			i--;
			Arr2[i][j] = nNum;
			printf("%d ", Arr2[i][j]);
			nCnt--;
			nNum++;
		}

		printf("\n");
		nCnt = szTemp;

		while (nCnt > 0)
		{
			j++;
			Arr2[i][j] = nNum;
			printf("%d ", Arr2[i][j]);
			nCnt--;
			nNum++;
		}

		printf("\n");
		szTemp -= 1;
		nCnt = szTemp;

		printf("\n");
	}

	for (i = 0; i < szNum; i++)
	{
		for (j = 0; j < szNum; j++)
		{
			printf("%10d", Arr2[i][j]);
		}
		printf("\n");
	}

	printf("\n");
}

void q3(void){}
void q4(void){}
void q5(void){}
void q6(void){}